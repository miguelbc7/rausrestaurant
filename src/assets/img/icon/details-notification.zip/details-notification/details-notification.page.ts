import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-notification',
  templateUrl: './details-notification.page.html',
  styleUrls: ['./details-notification.page.scss'],
})
export class DetailsNotificationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
